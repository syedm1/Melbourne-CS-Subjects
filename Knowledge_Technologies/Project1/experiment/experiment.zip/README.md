# Introduction

This is a experiment on spelling correction. We evaluate several algorithms on the same dataset. 

Source codes are in "code" folder
Datasets are in "data" folder
Results are in "result" folder

# Usage

Enter source code folder, run each algorithm with python <algorithm.py> without parameter. The result shows in the result folder
Run "python evaluate.py" and the final evaluate print on screen.
