module Project2 (initialGuess, nextGuess, GameState) where
import Data.List

type GameState = (Int, Int, [String], [String], [String])

initialGuess :: Int -> ([String],GameState)
initialGuess size = (gs, (1,size,bl,wh,[])) where 
    gs = replicate size "BP"
    bl = ["BP", "BN", "BB", "BR", "BQ", "BK"]
    wh = ["WP", "WN", "WB", "WR", "WQ", "WK"]

nextGuess :: ([String],GameState) -> (Int,Int,Int) -> ([String],GameState)
nextGuess (guess, (n, size, bl, wh, cer)) (f1,f2,f3) = (new_guess,((n+1),new_size,bl,wh,new_cer)) where
    new_size = size - f1 - f3
    new_cer = cer ++ (replicate f1 (nth n bl)) ++ (replicate f3 (nth n wh))
    new_guess = new_cer ++ (replicate new_size (nth (n+1) bl))

nth::Int -> [a] -> a
nth n lst = if n == 1 then head lst else otherwise = nth (n-1) (tail lst)
